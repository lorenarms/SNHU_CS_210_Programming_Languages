#pragma once



class cursorSet

{
public:
	void setNewCursor(int row, int col);

};

