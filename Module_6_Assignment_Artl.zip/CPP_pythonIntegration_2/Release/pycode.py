def PrintMe(v):
    print("You sent me: " + v)
    return 100;

def SquareValue(v):
    return v * v

def MultiplicationTable(x):
    print("The multiplication table for ", x, " is:")
    #for loop for displaying table
    for i in range(1, 11):
        #need to use commas to string unlike values together in print()
        print(x, " X ", i, " = ", x*i)

    return 0;

def DoubleValue(y):
    #simple, double the value and return
    y = y * 2;
    return y;